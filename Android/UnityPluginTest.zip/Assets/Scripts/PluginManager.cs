using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PluginManager : MonoBehaviour
{
    AndroidJavaObject m_AndroidJavaObject;
    AndroidJavaObject m_ActicityInstance;

    int nNaviveData = 0;

    void GetToastMsg(string text)
    {
        Debug.Log($"PluginManager.GetToastMsg 1");

        m_AndroidJavaObject.CallStatic("ShowToast", m_ActicityInstance, "Test");

        Debug.Log($"PluginManager.GetToastMsg 2");
    }

    // Start is called before the first frame update
    void Start()
    {
        Debug.Log($"PluginManager.Start 1");

        using (AndroidJavaClass unityPlayerClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
        {
            m_ActicityInstance = unityPlayerClass.GetStatic<AndroidJavaObject>("currentActivity");
            //m_ActicityInstance = unityPlayerClass.GetStatic<AndroidJavaClass>("currentActivity");
        }
        m_AndroidJavaObject = new AndroidJavaClass("com.sbsgame.androidplugin.Plugin");
        Debug.Log($"PluginManager.AndroidJavaObject:{m_AndroidJavaObject}");

        Debug.Log($"PluginManager.Start 2");
    }

    private void OnGUI()
    {
        if (GUI.Button(new Rect(0, 0, 300, 50), "ShowTostMsg"))
        {
            GetToastMsg("Test Android Plugin!");
        }
    }
}